﻿namespace Scheduling.Enums
{
    public enum Mode
    {
        Create,
        Edit,
        Delete
    }
}
