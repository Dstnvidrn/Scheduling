﻿namespace Scheduling.Data.Repositories
{
    public class AddressRepository
    {
    }
}
