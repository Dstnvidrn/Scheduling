﻿namespace Scheduling.Interfaces
{
    public interface IDataConnection
    {

    }
}
