﻿namespace Scheduling.Interfaces
{
    internal interface ICustomerMapper
    {
    }
}
